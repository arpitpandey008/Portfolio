<?php
$i = 20;
$s = "hello";
$arr = array(3, 4, 5); // Fixed array declaration
$fp = fopen("file.txt", "r"); // Corrected fopen function
var_dump($fp); // Dumps the file pointer
echo "<br/>";

var_dump($f); // Undefined variable, will cause a notice
echo "<br/>";

var_dump($i); // Dumps the value of $i
echo "<br/>";
?>